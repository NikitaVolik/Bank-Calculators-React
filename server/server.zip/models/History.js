import mongoose from "mongoose"

const historySchema = new mongoose.Schema({
    loanType: String,
    loanAmount: Number,
    termYears: Number,
    monthlyPayment: Number,
    totalPayment: Number
}, { timestamps: true })

const History = mongoose.model('History', historySchema)

export default History