import express from "express"
const router = express.Router()

function calculateLoan({loanAmount, annualRate, termYears}) {
    const monthlyRate = annualRate / 12 / 100 // Ежемесячная ставка
    const totalMonths = termYears * 12 // Количество месяцев
    const overallRate = Math.pow(1 + monthlyRate, totalMonths) // Общая ставка

    const monthlyPayment = (loanAmount * monthlyRate * overallRate) / (overallRate - 1) // Ежемесячный платёж
    const totalPayment = monthlyPayment * totalMonths // Общая сумма выплат

    return {
        monthlyPayment: Math.round(monthlyPayment),
        totalPayment: Math.round(totalPayment)
    }
}

// Эндпоинт для ипотеки
router.post("/mortgage", (req, res) => {
    const {loanAmount, termYears} = req.body // Получить параметры запроса
    const annualRate = 9.6 // Годовая ставка
    // console.log(`${loanAmount}, ${annualRate}, ${termYears}`)
    const result = calculateLoan({loanAmount, annualRate, termYears})
    if (!loanAmount || !termYears) {
        return res.status(400).json({message: "Missing required fields: loanAmount or termYears"})
    }
    res.json({type: "mortgage", ...result})
})

// Эндпоинт для автокредита
router.post("/car-loan", (req, res) => {
    const {loanAmount, termYears} = req.body // Получить параметры запроса
    const annualRate = 3.5 // Годовая ставка
    // console.log(`${loanAmount}, ${annualRate}, ${termYears}`)
    const result = calculateLoan({loanAmount, annualRate, termYears})
    if (!loanAmount || !termYears) {
        return res.status(400).json({message: "Missing required fields: loanAmount or termYears"})
    }
    res.json({type: "car-loan", ...result})
})

// Эндпоинт для потребительского
router.post("/consumer-loan", (req, res) => {
    const {loanAmount, termYears} = req.body // Получить параметры запроса
    const annualRate = 14.5 // Годовая ставка
    // console.log(`${loanAmount}, ${annualRate}, ${termYears}`)
    const result = calculateLoan({loanAmount, annualRate, termYears})
    if (!loanAmount || !termYears) {
        return res.status(400).json({message: "Missing required fields: loanAmount or termYears"})
    }
    res.json({type: "consumer-loan", ...result})
})

export default router