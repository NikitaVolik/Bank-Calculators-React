import express from "express"
const router = express.Router()

const loanData = {
    "mortgage": {
        "name": "Ипотечный кредит",
        "description": "Рассчитайте ежемесячный платёж по ипотеке с учётом процентной ставки",
        "annualRate": 9.6
    },
    "car-loan": {
        "name": "Кредит на приобретение автомобиля",
        "description": "Рассчитайте ежемесячный платёж по автокредиту",
        "annualRate": 3.5
    },
    "consumer-loan": {
        "name": "Потребительский кредит",
        "description": "Рассчитайте ежемесячный платёж по потребительскому кредиту",
        "annualRate": 14.5
    }
}

function calculateLoan({loanAmount, annualRate, termYears}) {
    const monthlyRate = annualRate / 12 / 100 // Ежемесячная ставка
    const totalMonths = termYears * 12 // Количество месяцев
    const overallRate = Math.pow(1 + monthlyRate, totalMonths) // Общая ставка

    const monthlyPayment = (loanAmount * monthlyRate * overallRate) / (overallRate - 1) // Ежемесячный платёж
    const totalPayment = monthlyPayment * totalMonths // Общая сумма выплат

    return {
        monthlyPayment: Math.round(monthlyPayment),
        totalPayment: Math.round(totalPayment)
    }
}

// Универсальный эндпоинт
router.post("/calculate", (req, res) => {
    const {loanType, loanAmount, termYears} = req.body // Получить параметры запроса

    if (!loanType || !loanData[loanType]) {
        return res.status(400).json({error: "Invalid loan type"})
    }

    if (!loanAmount || !termYears) {
        return res.status(400).json({error: "Missing required parameters"})
    }

    const annualRate = loanData[loanType].annualRate // Получаем годовую ставку
    
    const result = calculateLoan({loanAmount, annualRate, termYears})

    res.json({loanType, ...result})
})


// Получение списка и описания кредитов
router.get("/types", (req, res) => {
    const availableCalculators = Object.entries(loanData).map(([key, value]) => ({
        loanType: key,
        name: value.name,
        description: value.description
    }));

    res.json(availableCalculators)
})

// Добавление нового калькулятора
router.post("/types", (req, res) => {
    const {loanType, name, description, annualRate} = req.body

    if (!loanType || !name || !description || !annualRate) {
        return res.status(400).json({error: "Missing required fields"})
    }

    if (loanData[loanType]) {
        return res.status(400).json({error: "Loan type allready exists"})
    }

    loanData[loanType] = {name, description, annualRate}

    res.status(201).json({message: "Loan type added successfully"})
})

// Удаление калькулятора
router.delete("/types/:loanType", (req, res) => {
    const {loanType} = req.params

    if (!loanData[loanType]) {
        return res.status(404).json({error: "Loan type not found"})
    }

    delete loanData[loanType]

    res.json({message: "Loan type deleted successfully", loanType})
})

export default router