import express from "express"
import fs from "fs"
import path from "path"
import { authenticate, isAdmin } from "./auth.js"
import LoanCollection from "../models/LoanCollection.js"
import History from "../models/History.js"
import nodemailer from "nodemailer"
import dotenv from 'dotenv'

dotenv.config()

const router = express.Router()
const dataFilePath = path.resolve("./data/loanData.json")

// let loanData = JSON.parse(fs.readFileSync(dataFilePath, "utf-8"))

const transporter = nodemailer.createTransport({
    host: 'smtp.mail.ru',
    port: 465,
    secure: true,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS
    }
})

// Сохранение данных в формате JSON
function saveLoanData() {
    fs.writeFileSync(dataFilePath, JSON.stringify(loanData, null, 2))
}

function calculateLoan({loanAmount, annualRate, termYears}) {
    const monthlyRate = annualRate / 12 / 100 // Ежемесячная ставка
    const totalMonths = termYears * 12 // Количество месяцев
    const overallRate = Math.pow(1 + monthlyRate, totalMonths) // Общая ставка

    const monthlyPayment = (loanAmount * monthlyRate * overallRate) / (overallRate - 1) // Ежемесячный платёж
    const totalPayment = monthlyPayment * totalMonths // Общая сумма выплат

    return {
        monthlyPayment: Math.round(monthlyPayment),
        totalPayment: Math.round(totalPayment)
    }
}

// Универсальный эндпоинт
router.post("/calculate", async (req, res) => {
    const { loanType, loanAmount, termYears } = req.body

    if (!loanType || !loanAmount || !termYears) {
        return res.status(400).json({ error: "Missing required parameters" })
    }

    console.log(req.body)

    try {
        const loanData = await LoanCollection.findOne()

        if (!loanData || !loanData.loans.has(loanType)) {
            // console.log(loanData)
            // console.log(loanData.loans.has(loanType))
            return res.status(400).json({ error: "Invalid loan type" })
        }

        const { annualRate, name } = loanData.loans.get(loanType)
        const result = calculateLoan({ loanAmount, annualRate, termYears })

        console.log(result)

        const historyEntry = new History({
            loanType,
            loanAmount,
            termYears,
            monthlyPayment: result.monthlyPayment,
            totalPayment: result.totalPayment
        })

        console.log(historyEntry)

        await historyEntry.save()

        res.json({
            loanType,
            name,
            ...result
        })
    } catch (error) {
        res.status(500).json({ error: "Database error" })
    }
})


// Получение списка и описания кредитов
router.get("/types", async (req, res) => {
    try {
        const loanData = await LoanCollection.findOne()
        if (!loanData) return res.json([])

        const availableCalculators = Array.from(loanData.loans.entries()).map(([key, value]) => ({
            loanType: key,
            name: value.name,
            description: value.description,
            annualRate: value.annualRate
        }))

        res.json(availableCalculators)
    } catch (error) {
        res.status(500).json({ error: "Database error" })
    }
})

// Отправка почты
router.post("/send-email", async (req, res) => {
    const {email, loanData} = req.body

    console.log(email, loanData)

    if (!email || !loanData) {
        return res.status(404).json({error: "Email and loanData are required"})
    }

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: email,
        subject: "Результат расчёта кредита",
        html: `
            <h2>Результат расчёта кредита</h2>
            <p><strong>Тип кредита: </strong>${loanData.name}</p>
            <p><strong>Ежемесячный платёж: </strong>${loanData.monthlyPayment}</p>
            <p><strong>Общая сумма выплат: </strong>${loanData.totalPayment}</p>
        `
    }

    try {
        await transporter.sendMail(mailOptions)
        res.json({message: "Email успешно отправлен"})
    } catch (err) {
        console.error({error: "Ошибка отправки письма: ", err})
        res.status(500).json({error: "Ошибка отправки письма: ", details: err.message})
    }
})

/************************************************************
Секция администратора 
************************************************************/

// Добавление нового калькулятора
router.post("/types", authenticate, isAdmin, async (req, res) => {
    const { loanType, name, description, annualRate } = req.body

    if (!loanType || !name || !description || !annualRate) {
        return res.status(400).json({ error: "Missing required fields" })
    }

    try {
        let loanData = await LoanCollection.findOne()
        if (!loanData) {
            loanData = new LoanCollection({ loans: new Map() })
        }

        if (loanData.loans.has(loanType)) {
            return res.status(400).json({ error: "Loan type already exists" })
        }

        loanData.loans.set(loanType, { name, description, annualRate })
        await loanData.save()

        res.status(201).json({ message: "Loan type added successfully" })
    } catch (error) {
        res.status(500).json({ error: "Database error" })
    }
})


// Удаление калькулятора
router.delete("/types/:loanType", authenticate, isAdmin, async (req, res) => {
    const {loanType} = req.params

    // console.log(loanType)

    try {
        let loanData = await LoanCollection.findOne()
        // console.log(loanData.loans.get(loanType))
        
        if (!loanData || !loanData.loans.get(loanType)) {
            return res.status(404).json({error: "Loan type not found"})
        }

        delete loanData.loans.delete(loanType)
        await loanData.save()

        res.json({message: "Loan type deleted successfully", loanType})
    } catch (error) {
        res.status(500).json({error: "Database error"})
    }
})

// Изменение калькулятора
router.put("/types/", authenticate, isAdmin, async (req, res) => {

    const {loanType, name, description, annualRate} = req.body

    if (!loanType) {
        return res.status(400).json({error: "Loan type is required"})
    }

    try {
        const loanData = await LoanCollection.findOne()
        if (!loanData || !loanData.loans.get(loanType)) {
            return res.status(404).json({error: "Loan type not found"})
        }
        
        loanData.loans.set(loanType, {
            name: name || loanData.loans.get(loanType).name,
            description: description || loanData.loans.get(loanType).description,
            annualRate: annualRate || loanData.loans.get(loanType).annualRate
        })

        await loanData.save()

        res.json({message: "Loan type updated successfully", loanType})
    } catch (error) {
        // console.log(error.message)
        res.status(500).json({error: "Database error", details: error.message })
    }
})

router.get("/history", authenticate, isAdmin, async (req, res) => {
    try {
        const history = await History.find().sort({createdAt: 1})

        res.json(history)
    } catch (error) {
        console.error('Error retrieving history')
        res.status(500).json({error: "Database error", details: error.message })
    }
})

router.delete("/history", authenticate, isAdmin, async (req, res) => {
    try {
        await History.deleteMany({})

        res.json({message: "History cleared successfully"})
    } catch (error) {
        res.status(500).json({error: "Database error", details: error.message })
    }
})

export default router