import express from "express"
const router = express.Router()

const loanRates = {
    "mortgage": 9.6,
    "car-loan": 3.5,
    "consumer-loan": 14.5
}

function calculateLoan({loanAmount, annualRate, termYears}) {
    const monthlyRate = annualRate / 12 / 100 // Ежемесячная ставка
    const totalMonths = termYears * 12 // Количество месяцев
    const overallRate = Math.pow(1 + monthlyRate, totalMonths) // Общая ставка

    const monthlyPayment = (loanAmount * monthlyRate * overallRate) / (overallRate - 1) // Ежемесячный платёж
    const totalPayment = monthlyPayment * totalMonths // Общая сумма выплат

    return {
        monthlyPayment: Math.round(monthlyPayment),
        totalPayment: Math.round(totalPayment)
    }
}

// Универсальный эндпоинт
router.post("/calculate", (req, res) => {
    const {loanType, loanAmount, termYears} = req.body // Получить параметры запроса

    if (!loanType || !loanRates[loanType]) {
        return res.status(400).json({error: "Invalid loan type"})
    }

    if (!loanAmount || !termYears) {
        return res.status(400).json({error: "Missing required parameters"})
    }

    const annualRate = loanRates[loanType] // Получаем годовую ставку
    
    const result = calculateLoan({loanAmount, annualRate, termYears})

    res.json({loanType, ...result})
})

export default router